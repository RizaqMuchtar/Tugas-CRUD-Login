-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2024 at 06:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `KurangiStokBarang` (IN `product_id` INT, IN `quantity` INT)   BEGIN
    UPDATE tbl_barang
    SET stok = stok - quantity
    WHERE id_barang = product_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `email`, `password`) VALUES
(1, 'kamukuliah@dimana.sih', 'cc1td0ng'),
(2, 'kuliahenaknya@dimana.ya', 'cc1tAja'),
(3, 'ahmad.dasawarsa@milik.bumd', 'ahmad10tahun'),
(4, 'fajrisatuabad@milik.bumd', 'fajrimenolaktua1000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_barang`
--

CREATE TABLE `tbl_barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(255) DEFAULT NULL,
  `desc_barang` varchar(255) DEFAULT NULL,
  `harga_barang` int(30) DEFAULT NULL,
  `stok` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_barang`
--

INSERT INTO `tbl_barang` (`id_barang`, `nama_barang`, `desc_barang`, `harga_barang`, `stok`) VALUES
(25, 'Daging Ayam', '1 Ekor', 8000, 100),
(26, 'Beras', '5 Kg', 30000, 100),
(27, 'Telur Ayam', '1 Tray', 10000, 100),
(28, 'Ikan Kembung', '1 kg', 13000, 100),
(29, 'Susu UHT', '1 Karton', 30000, 100),
(30, 'Daging Sapi', '1 Kg', 35000, 100),
(32, 'Pensil', '5 pcs', 5000, 20),
(33, 'Pack Alat Tulis', '1 Pcs (2xPensil, 1xPenghapus, 1xPenggaris30cm)', 7000, 30),
(34, 'Ransum', '1 Pack', 20000, 10),
(35, 'Pulpen', '1 Box @ 10 pcs', 10000, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
